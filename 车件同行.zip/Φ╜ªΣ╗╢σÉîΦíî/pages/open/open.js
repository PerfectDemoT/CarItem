

var app=getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    wx.login({
      success: res => {

      }
    })     
    wx.getUserInfo({
      success(res){
        app.data.user_name = res.userInfo.nickName
        wx.request({
          url: 'http://ae00880e.ngrok.io/login',
          data:{        
            user_name:app.data.user_name
          },
          success(res){
           
            if (res.data.length != 0) {
              
              wx.switchTab({
                url: '/pages/index/index',
              })
            }
            else{
            wx.getUserInfo({
              success(res) {
               
                wx.showModal({
                  title: '微信授权                车件同行申请获得以下权限:',
                  content: '*获得你的公开信息（昵称，头像等）',
                  success: function (res) {
                    if (res.confirm) {
                    wx.getUserInfo({
                      success(res) {
                        var that = this

                        wx.request({
                          url: 'http://ae00880e.ngrok.io',

                          data: {
                            user_name: res.userInfo.nickName,
                            gender: res.userInfo.gender,
                            tele:1231232112,
                            credit:5,
                            addtime:"21312749812",
                            convey_success:5,

                          },
                          method: 'GET',
                        })
                        wx.switchTab({
                          url: '/pages/index/index',
                        })
                      }
                      
                    })
                  }
                  }
                })
              
              }
            })    
          }
          }  
    }) 
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  btn:function(){
    wx.redirectTo({
      url: '/pages/index/index',
    })
  },
  getPhoneNumber:function(e){
   console.log(e.detail.errMsg)
    console.log(e.detail.iv)
    console.log(e.detail.encryptedData) 
    wx.redirectTo({
      url: '/pages/index/index',
    })
  }
})
