var app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    array:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
     var that=this
     wx.request({
       url: 'https://74e867df.ngrok.io/CarItem/neighborhood.php',
       
       success(res){
         console.log(res)
         that.setData({
           array:res.data
         })
       }
     })
    
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  formSubmit:function(e){
    var that=this
    var input1=e.detail.value.input
    wx.request({
      url: "https://81450f6d.ngrok.io/CarItem/search.php",
      data:{
       search_name:input1
      },
      success(res){
        that.setData({
          array:res.data
        })
      }
    })
    wx.redirectTo({
      url: '/pages/to_send/to_send',
    })
  },
  btn:function(){
    console.log("1----1")
    app.data.index1=1
  },
  bindtap:function(res){
     app.data.index=res.currentTarget.id
     console.log(res.currentTarget.id)
     wx.navigateTo({
       url: '/pages/to_send/detail/detail',
     })
  }
})