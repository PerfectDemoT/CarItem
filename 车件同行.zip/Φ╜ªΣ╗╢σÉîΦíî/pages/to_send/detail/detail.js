
var app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index:0,
    array:[],
    type:"",
    x1:0,
    x2: 0,
    x3: 0,
    x4: 0,
    y1:0,
    y2: 0,
    y3: 0,
    y4: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   var that=this
   var n1=0
   var n2=0
   var n3 = 0
   var n4 = 0
   var n5 = 0
   var n6 = 0
   var temp1=0
   var temp2=0
   var m1=0
   var m2=0
   that.setData({
     index:app.data.index
   })
   console.log(app.data.index)
    wx.request({
      url: 'https://74e867df.ngrok.io/CarItem/neighborhood.php',
      success(res) {
        that.setData({
          array: res.data,
          type: res.data[app.data.index].convey_class,
        })
        temp1= res.data[app.data.index].time_start,
          temp2 = res.data[app.data.index].time_end
          console.log(temp1)
          console.log(temp2)
          m1=temp1%1000000
          m2=temp1-m1
          m2=m2/1000000
        that .setData({
        x1:m2
        })
        n1=m2
              console.log(n1)
        n2 = temp1 - n1 * 1000000
            console.log(n2)
          m1=n2%10000
          m2=n2-m1
          m2=m2/10000
          that.setData({
            x2:m2
          })
        n3=m1
              console.log(n3)
         m1=n3%100
         m2=n3-m1
         m2=m2/100
        that.setData({
          x3: m2
        })
        console.log(m2)
        console.log(m1)
        that.setData({
          x4: m1
        })   

        m1 = temp2 % 1000000
        m2 = temp2 - m1
        m2 = m2 / 1000000
        that.setData({
          y1: m2
        })
        n1 = m2
        console.log(n1)
        n2 = temp2 - n1 * 1000000
        console.log(n2)
        m1 = n2 % 10000
        m2 = n2 - m1
        m2 = m2 / 10000
        that.setData({
          y2: m2
        })
        n3 = m1
        console.log(n3)
        m1 = n3 % 100
        m2 = n3 - m1
        m2 = m2 / 100
        that.setData({
          y3: m2
        })
        console.log(m2)
        console.log(m1)
        that.setData({
          y4: m1
        })   


        
            
        
        if (res.data[app.data.index].convey_class==0){
          that.setData({
            type:"普通快件"
          })
        }
        else if (res.data[app.data.index].convey_class == 1){
          that.setData({
            type: "佛系快件"
          })
        }
        else{
          that.setData({
            type: "加急快件"
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  btn1:function(){
    app.data.index = 0
    wx.redirectTo({
      url: '/pages/success/success',
    })
  },
  btn2: function () {
    app.data.index=0
    wx.switchTab({
      url: '/pages/to_send/to_send',
    })
  }
})