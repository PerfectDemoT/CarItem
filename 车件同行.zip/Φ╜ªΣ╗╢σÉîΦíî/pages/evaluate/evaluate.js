
var app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    items: [
      { name: 'USA', value: '1' },
      { name: 'CHN', value: '2' },
      { name: 'BRA', value: '3', checked: 'true' },
      { name: 'JPN', value: '4' },
      { name: 'ENG', value: '5' },
    ],
    value:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  radioChange:function(e){
     var that =this
     that.setData({
       value: e.detail.value
     })
  },
  formSubmit:function(res){
    var value1
    var that=this
    value1=res.detail.value.radio_group
     wx.request({
       url: 'http://ae00880e.ngrok.io/star',
       data:{
         stars: 2,
         item_id:123,
         name_ID:231
       }
     })
  },
  btn:function(){
    console.log("1--1")
    wx.switchTab({
      
      url: '/pages/index/index',
    })
  }
})