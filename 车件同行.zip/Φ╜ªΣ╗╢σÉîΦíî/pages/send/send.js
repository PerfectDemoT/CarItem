
var app=getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    index1:0,
    index2:0,
    index3:0,
    index4:0,
    index5:0,
    index6:0,
    index7: 0,
    index8: 0,
    index9: 0,
    index12: 0,
    index10: 0,
    index11: 0,
    index13: 0,
    time1:[1,2,3,4,5,6,7,8,9,10,11,12],
    time2:[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31],
    time3: [0,1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23 ],
    time5:[0,10,20,30,40,50],
    content:["普通快件","佛系快件","加急快件"]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  formSubmit:function(e){
    var picker1=e.detail.value.picker1
    var item_class1 = e.detail.value.input2
    var weight1 = e.detail.value.input1
    var send_address1 = e.detail.value.input3
    var get_address1 = e.detail.value.input4
    var price1 = e.detail.value.input5
    var input1 = e.detail.value.input
    var x = e.detail.value.picker5 *10
    x = x + e.detail.value.picker4 * 100
    x = x + e.detail.value.picker3 * 10000+10000
    x = x + e.detail.value.picker2 * 1000000+1000000
    var y = e.detail.value.picker9 * 10
    y = y + e.detail.value.picker8 * 100
    y = y + e.detail.value.picker7 * 10000 + 10000
    y = y + e.detail.value.picker6 * 1000000 + 1000000
    console.log(x)
    console.log(y)
    console.log(app.data.user_name)
    console.log(e.detail.value.picker1)
    console.log(item_class1)
    console.log(weight1)
    console.log(send_address1)
    console.log(get_address1)
    console.log(price1)
    wx.request({
      url: 'https://74e867df.ngrok.io/CarItem/unreceive.php',
      data:{
        item_name:input1,
        user_name: app.data.user_name,
        convey_class:picker1,
        item_class: item_class1,
        weight: weight1,
        send_address: send_address1,
        get_address: get_address1,
        price: price1,
        time_start:x,
        time_end:y,
      },
      method:"GET"
    })
    
  },
  bindChange4: function (e) {
    this.setData({
      index4: e.detail.value
    })
  },
  bindChange1: function (e) {
    this.setData({
      index1: e.detail.value
    })
  },
  bindChange2: function (e) {
    this.setData({
      index2: e.detail.value
    })
  },
  bindChange3: function (e) {
    this.setData({
      index3: e.detail.value
    })
  },
  bindChange5: function (e) {
    this.setData({
      index5: e.detail.value
    })
  },
  bindChange6: function (e) {
    this.setData({
      index6: e.detail.value
    })
  },
  bindChange7: function (e) {
    this.setData({
      index7: e.detail.value
    })
  },
  bindChange8: function (e) {
    this.setData({
      index8: e.detail.value
    })
  },
  bindChange9: function (e) {
    this.setData({
      index9: e.detail.value
    })
  },
  bindChange10: function (e) {
    this.setData({
      index10: e.detail.value
    })
  },
  bindChange11: function (e) {
    this.setData({
      index11: e.detail.value
    })
  },
  bindChange12: function (e) {
    this.setData({
      index12: e.detail.value
    })
  },
  bindChange13: function (e) {
    this.setData({
      index13: e.detail.value
    })
  },
  btn:function(){
    wx.navigateTo({
      url: '/pages/success/success',
    })
  }

})