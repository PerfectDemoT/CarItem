
var app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
   
      user_name:"1",
      user_image:"",
      encryptedData:{
    
      },
      array:[],
      array1:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this
    var a
    
    var b
    var c
    var d
    var e
    var array2
    wx.login({
      
    })
    wx.getUserInfo({
      success(res){
        that.setData({
          user_name: res.userInfo.nickName,
          user_image: res.userInfo.avatarUrl,
          
        })

      }
    })
    wx.request({
      url: 'http://ae00880e.ngrok.io/suggest',
      data:{
        id:123,
      },
      success(res){
        array2 = res.data.diction
        a = array2[0][1]
        b = array2[1][1]
        c = array2[2][1]
        d = array2[3][1]
        e = array2[4][1]
        console.log(a)
        console.log(b)
        wx.request({
          url: 'https://74e867df.ngrok.io/CarItem/recommend.php',
          data: {
            item_class1: a,
            item_class2: b,
            item_class3: c,
            item_class4: d,
            item_class5: e
          },
          success(res) {
            console.log(res)
            that.setData({
              array: res.data
            })
          }
        })
      } 
    })
    
   

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  btn1:function(){
    wx.navigateTo({
      url: '/pages/index/unrecived/unrecived',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  btn2: function () {
    wx.navigateTo({
      url: '/pages/index/unfinished/unfinished',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  }, 
  btn3: function () {
    wx.navigateTo({
      url: '/pages/index/finished/finished',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  btn4: function () {
    wx.navigateTo({
      url: '/pages/index/question/question',
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  btn5:function(res){
    app.data.index = res.currentTarget.id
    console.log(res.currentTarget.id)
    wx.navigateTo({
      
      url: '/pages/to_send/detail/detail',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  }
})